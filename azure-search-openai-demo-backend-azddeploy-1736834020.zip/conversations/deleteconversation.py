from azure.storage.blob import ContainerClient
from util.logger import create_debug_conversationlog_error, create_debug_conversationlog_info

def deleteConversationBlob(blob_container:ContainerClient, env:str, conversation):
    """引数に渡されたconversationをblobから削除します。
    """
    try:
        # "yyyy/mm/dd HH:MM:ss" → "yyyymmdd_HHMMss"形式の文字列に変換
        formatted_datetime = conversation["conversation_timestamp"].replace('/', '').replace(' ', '_').replace(':', '')
        # Blobから削除するファイル名
        blob_name = conversation["userid"] + "/" + conversation["tenant"] + "/conversation_" + formatted_datetime
        # Blobから削除
        blob_client = blob_container.get_blob_client(blob_name)
        if blob_client:
            blob_client.delete_blob()
            create_debug_conversationlog_info(env, "delete", conversation)
            return {"message": "done" }
        else:
            create_debug_conversationlog_error(env, "delete", conversation, "Already deleted or file does not exist.")
            return {"message": "Already deleted or file does not exist." }
    except Exception as e:
        create_debug_conversationlog_error(env, "delete", conversation, "Delete failed.")

       
def deletePastConversationBlob(blob_container:ContainerClient, blob_data, env:str, stockedconversationNum:int):
    """
    stockedconversationNum以上の過去の会話をblobから削除し、
    最新の会話stockedconversationNum件分を返却します。
    """
    # 削除する過去の会話を取得
    conversation_to_delete = blob_data["conversations"][stockedconversationNum:]

    # Blobから削除
    for conversation in conversation_to_delete:
        deleteConversationBlob(blob_container, env, conversation)
    
    # 指定した値分の会話を返却
    blob_data["conversations"] = blob_data["conversations"][:stockedconversationNum]

    return blob_data

