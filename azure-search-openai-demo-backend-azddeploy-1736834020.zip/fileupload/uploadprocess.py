import fitz 
import re
import os
import math
import json
import io
import base64
import ast
import requests
import msoffcrypto
from concurrent.futures import ThreadPoolExecutor
from PIL import Image, ImageSequence

ALLOW_FILE_CAPACITY = float(os.environ.get("ALLOW_FILE_CAPACITY") or 1000000)
ALLOW_FILE_LENGTH= int(os.environ.get("ALLOW_FILE_LENGTH") or "40000")
IMAGE_DPI = int(os.environ.get("IMAGE_DPI") or "300") 
AZURE_FUNCTION_APP_NAME = os.environ.get("AZURE_FUNCTION_APP_NAME") or "func-aiassistant-st-03"
AZURE_FUNCTION_NAME_2PDF = os.environ.get("AZURE_FUNCTION_NAME_2PDF") or "HttpExample"
AZURE_FUNCTION_KEY_2PDF  = os.environ.get("AZURE_FUNCTION_KEY_2PDF") or "function_key"
AZURE_FUNCTIONS_URL = f'https://{AZURE_FUNCTION_APP_NAME}.azurewebsites.net/api/{AZURE_FUNCTION_NAME_2PDF}?'

def get_file_chunk_info(dt,jsonData,files,env):   #GPT-3.5の場合のファイルアップロード
    overrides = jsonData["overrides"]
    for file in files:
        if not file or file.filename == '':
            return 'No selected file', 400
        #ファイル名、ファイル容量、ファイル形式の確認
        file_size = len(file.read()) # ファイルのサイズ（バイト）を取得します
        file.seek(0) 
        filename = file.filename
        #テキスト情報の抽出
        file_stream = file.read()
        fileup_result = uploadfile_return(file_stream, filename, file_size, jsonData["acceptFile"])
        debug_fileUploadlog={
            "debug_fileUploadlog":{
                "username": overrides.get("user_name"),
                "userid": overrides.get("user_id"),
                "userdepartment": overrides.get("user_department"),
                "starttime":dt,
                "type":"info",
                "env":env,
                "file_name": filename,
                "file_size":str(file_size)+"byte"
            }
        }
        print(json.dumps(debug_fileUploadlog, ensure_ascii=False),flush=True)
    return fileup_result

def get_file_image_info(dt,jsonData,files,env):   #GPT-4oの場合のファイルアップロード
    filename_list = []
    check_result = {}
    check_list =[]
    overrides = jsonData["overrides"]
    acceptFile = jsonData["acceptFile"]
    doc_types = [value for sublist in acceptFile["accept"].values() for value in sublist]   #対応しているファイル形式
    # ACCEPT_MAX_PAGE = acceptFile['maxFiles']    #受け入れ可能な画像ファイル数。ファイル上限を設けたい場合はこれを使う。

    base64_image_list = []
    image_file_size_list = []
    for file_num,file in enumerate(files):
        if not file or file.filename == '':
            return 'No selected file', 400
        #ファイル名、ファイル容量、ファイル形式の確認
        filename = file.filename
        filename_list.append(filename)
        ext = os.path.splitext(filename)[1].lower()
        file.seek(0) 
        #対象のファイルかチェック
        if not ext in doc_types:
            check_list.append(f'ファイル形式が利用条件を満たしていません。\n')
            check_result["message"]="".join(check_list)
            return check_result
        
        #対象ファイルで場合分け
        if ext in ['.pdf']:
            pdf_bytes = file.read() #ファイルの読み込み
            doc = fitz.open(stream=pdf_bytes, filetype="pdf")
            # パスワードで保護されてる場合エラーを返す
            if doc.needs_pass:
                check_list.append(f'ファイルにパスワードが設定されています。パスワード設定を解除してください。\n')
                check_result["message"]="".join(check_list)
                return check_result
            
            #PDFを画像に変換し、base64変換をする
            base64_image_list,image_file_size_list = convert_pdf_to_image(doc,base64_image_list,image_file_size_list,ext)
        
        elif ext in ['.ppt','.pptx','.doc','.docx']:
            #パスワードがかかっているかチェック
            document = msoffcrypto.OfficeFile(file)
            # パスワードで保護されてる場合エラーを返す
            if document.is_encrypted():
                check_list.append(f'ファイルにパスワードが設定されています。パスワード設定を解除してください。\n')
                check_result["message"]="".join(check_list)
                return check_result
            file.seek(0)
            
            #Azure FunctionsのAPIでPPTファイルをPDFに変換
            files = {'file':(file.filename,file.stream,file.mimetype)}
            headers = {'x-functions-key': AZURE_FUNCTION_KEY_2PDF}
            response = requests.post(AZURE_FUNCTIONS_URL,files=files,headers=headers)
            pdf_bytes = response.content
            ext = '.pdf'    #拡張子をpdfに変更
            doc = fitz.open(stream=pdf_bytes, filetype="pdf")            
            #PDFを画像に変換し、base64変換をする
            base64_image_list,image_file_size_list = convert_pdf_to_image(doc,base64_image_list,image_file_size_list,ext)

        elif ext in ['.gif', '.webp', '.tif', '.tiff']:
            # 画像ファイルを開く
            image = Image.open(file.stream)  
            if ext == '.gif':
                # GIFファイルの場合、各フレームを取得
                frames = process_gif(image)
                # 各フレームをbase64に変換し、リストに追加
                base64_image_list, image_file_size_list = convert_image_to_base64(base64_image_list, image_file_size_list, frames, [ext]*len(frames))
            elif ext in ['.tif', '.tiff']:
                # TIFFファイルの場合、各ページを取得
                frames = process_tiff(image)
                # 各ページをbase64に変換し、リストに追加
                base64_image_list, image_file_size_list = convert_image_to_base64(base64_image_list, image_file_size_list, frames, [ext]*len(frames))
            else:
                # WebPなどその他の画像形式の場合、そのままbase64に変換しリストに追加
                base64_image_list, image_file_size_list = convert_image_to_base64(base64_image_list, image_file_size_list, [image], [ext])

        elif ext in ['.png', '.jpeg', '.jpg']:
            image = Image.open(file.stream)  # 画像ファイルを開く
            base64_image_list, image_file_size_list = convert_image_to_base64(base64_image_list, image_file_size_list, [image], [ext])

        elif ext in ['.png','.jpeg','.jpg']:
            image_file = file.read() #ファイルの読み込み
            image_file_size = len(image_file)    #filesizeを取得    #画像ファイルサイズを取得。
            #base64に変換
            img_base64 = base64.b64encode(image_file).decode('utf-8') #画像のバイトデータをbase64エンコード
            base64_image_list.append(img_base64)
            image_file_size_list.append(f'{image_file_size}byte')
        else :
            print("ファイルチェックを通ったファイル.修正必至")   #TO DO
    #エラーメッセージを処理
    for item in image_file_size_list:
        if "message" in item:
            try:
                # 文字列を辞書に変換する
                item = item.replace('byte', '')
                parsed_item = ast.literal_eval(item)
                if 'message' in parsed_item:
                    return parsed_item
            except (ValueError, SyntaxError):
                continue
        
    debug_fileUploadlog={
        "debug_fileUploadlog":{
            "username": overrides.get("user_name"),
            "userid": overrides.get("user_id"),
            "userdepartment": overrides.get("user_department"),
            "starttime":dt,
            "type":"info",
            "env":env,
            "file_name": filename_list,
            "file_size":image_file_size_list
        }
    }
    print(json.dumps(debug_fileUploadlog, ensure_ascii=False),flush=True)
    result_json ={"filenames":filename_list,"base64_images":base64_image_list}
    
    return result_json

def uploadfile_return(file_stream, filename, filesize, acceptFile):
    filename_list = []  #gpt4oに合わせたいのでlist型に
    #ファイル形式の確認
    doc_types = [value for sublist in acceptFile["accept"].values() for value in sublist]
    filetype_check_result = specification_file_type_check(filename, doc_types)
    if(len(filetype_check_result["message"])>0):
        return filetype_check_result
    #ファイル容量、ファイルサイズの確認
    page_map=get_document_text(file_stream)
    text_length = len("".join(p[2] for p in page_map))    
    fileother_check_result =specification_file_other_check(filename, filesize, text_length)
    if(len(fileother_check_result["message"])>0):
        return  fileother_check_result
    split_text_data = split_text(page_map)
    filename_list.append(filename)
    result_json ={"filenames":filename_list,"chunk":split_text_data}
    return result_json

def specification_file_type_check(filename, doc_types):
    check_result ={}
    check_list=[]
    check_result["filename"]=filename
    file_type = os.path.splitext(filename)[1].lower()
    if file_type not in doc_types:
        check_list.append("ファイル形式が利用条件を満たしていません。\n")
    check_result["message"]="".join(check_list)
    return check_result

def specification_file_other_check(filename, filesize, text_length):

    check_result ={}
    check_list=[]
    check_result["filename"]=filename
    if filesize >ALLOW_FILE_CAPACITY:
        check_list.append("ファイル容量が上限を超えています。\n")
    if text_length >ALLOW_FILE_LENGTH:
        check_list.append("文字数上限を超えています。\n")
    check_result["message"]="".join(check_list)
    return check_result



def get_document_text(file_stream):
    #テキスト情報の抽出
    offset = 0
    page_map = []
    doc = fitz.open(stream=file_stream, filetype="pdf")
    for page_num, p in enumerate(doc):
        page_text = p.get_text()
        # Shift-JISでデコード
        decoded_text = page_text.encode('shift_jis', 'ignore').decode('shift_jis', 'ignore')
        # UTF-8でエンコード.
        encoded_text = decoded_text.encode('utf-8', 'ignore')
        text = encoded_text.decode('utf-8')
        page_map.append((page_num, offset, text))
        offset += len(page_text)
    return page_map



def split_text(page_map):
    MAX_SECTION_LENGTH = int(os.environ.get("UPLOAD_MAX_SECTION_LENGTH") or "5000")
    SENTENCE_SEARCH_LIMIT = int(os.environ.get("UPLOAD_SENTENCE_SEARCH_LIMIT") or "0")
    SECTION_OVERLAP = int(os.environ.get("UPLOAD_SECTION_OVERLAP") or "0")
    SENTENCE_ENDINGS= [".","。", "!", "！", "?", "？"] #文章の終わるタイミング
    WORDS_BREAKS = [",","、",  ";", "；",":", "：", " ","　", "(", ")","（", "）", "[", "]", "［", "］", "{", "}","｛", "｝", "\t", "\n"] #文字の区切りタイミング
    def find_page(offset):#該当の文字が何ページ目に入っているのか確認する関する
        l = len(page_map)
        for i in range(l - 1):
            if offset >= page_map[i][1] and offset < page_map[i + 1][1]:
                return i
        return l - 1
    split_text_list=[]
    all_text = "".join(p[2] for p in page_map)
    length = len(all_text)
    start = 0
    end = length

    #分割する文字数を計算する
    if length>MAX_SECTION_LENGTH:
        N=math.ceil(float(length)/float(MAX_SECTION_LENGTH))
        MAX_SECTION_LENGTH = math.ceil(length/N)
            
    i=0
    while start + SECTION_OVERLAP < length:
        last_word = -1
        end = start + MAX_SECTION_LENGTH

        if end > length:
            end = length #何回目かの計算で終わり位置が文字の最後を超えたらendを文字の終わりにする
        else:
            # Try to find the end of the sentence 暫定のendより後の end of sentence を探す
            while end < length and (end - start - MAX_SECTION_LENGTH) < SENTENCE_SEARCH_LIMIT and all_text[end] not in SENTENCE_ENDINGS:
                if all_text[end] in WORDS_BREAKS:
                    last_word = end
                end += 1
            if end < length and all_text[end] not in SENTENCE_ENDINGS and last_word > 0:#whileでブレイクポイントを見つけられなかった＆ちょうど文字の区切りだった場合の処理
                end = last_word # Fall back to at least keeping a whole word　最後の言葉を文字の区切りにする
        if end < length:
            end += 1

        # Try to find the start of the sentence or at least a whole word boundary
        last_word = -1
        while start > 0 and start > end - MAX_SECTION_LENGTH - 2 * SENTENCE_SEARCH_LIMIT and all_text[start] not in SENTENCE_ENDINGS:
            if all_text[start] in WORDS_BREAKS:#文字の区切りを探す
                last_word = start
            start -= 1
        if all_text[start] not in SENTENCE_ENDINGS and last_word > 0:#始まりの言葉が文の終わりじゃなくてちょうど文字の文字の始まりの場合
            start = last_word
        if start > 0:
            start += 1#文字の区切りなので戻す

        section_text = all_text[start:end]
        split_text_list.append([section_text, find_page(start),  find_page(end)])

        last_table_start = section_text.rfind("<table")
        if (last_table_start > 2 * SENTENCE_SEARCH_LIMIT and last_table_start > section_text.rfind("</table")):
             start = min(end - SECTION_OVERLAP, start + last_table_start)
        else:
            start = end - SECTION_OVERLAP
        if(start+1>length):
            break
    else:
        split_text_list.append([all_text[start:length], find_page(start),  find_page(length)])

    return split_text_list

def process_gif(image):
    """
    GIFの各フレームをリストに追加する関数
    """
    frames = []
    for frame in ImageSequence.Iterator(image):
        frames.append(frame.convert("RGBA"))
    return frames

def process_tiff(image):
    """
    TIFFファイルの各ページをリストに追加する関数
    """
    frames = []
    for frame in ImageSequence.Iterator(image):
        frames.append(frame.convert("RGBA"))
    return frames

def pixmap_to_image(pixmap):
    """
    PixmapオブジェクトをPillowのImageオブジェクトに変換するヘルパー関数
    """
    mode = "RGBA" if pixmap.alpha else "RGB"
    img = Image.frombytes(mode, [pixmap.width, pixmap.height], pixmap.samples)
    return img

def encode_image(image):
    """
    画像をJPEGに変換し、base64エンコードする関数
    """
    if image.mode == 'RGBA':
        image = image.convert('RGB')  # JPEGはRGBAモードをサポートしないため、RGBに変換
    bufferd = io.BytesIO()  # byte streamを作成（一時的に画像データを保存）
    image.save(bufferd, format="JPEG")  # 各ページをJPEG形式でバッファに保存
    img_byte = bufferd.getvalue()  # バッファ内のデータをbyte形式で取得
    image_file_size = len(img_byte)  # filesizeを取得
    img_base64 = base64.b64encode(img_byte).decode('utf-8')  # JPEG画像のバイトデータをbase64エンコード
    return img_base64, image_file_size

def convert_image_to_base64(base64_image_list, image_file_size_list, images, exts):
    """
    複数の画像を並列処理でbase64に変換する関数
    """
    try:
        # 一時的なリストを作成して、変換後のbase64文字列とファイルサイズを格納する
        tmp_base64_image_list = [None] * len(images)
        tmp_image_file_size_list = [None] * len(images)
        
        # ThreadPoolExecutorを使用して並列処理を実行
        with ThreadPoolExecutor() as executor:
            futures = {}
            # 各画像をエンコードするためのタスクをスケジュール
            for idx, (image, ext) in enumerate(zip(images, exts)):
                if isinstance(image, fitz.Pixmap):
                    # PixmapオブジェクトをPillowのImageオブジェクトに変換
                    image = pixmap_to_image(image)
                # エンコードタスクをスケジュールし、Futureオブジェクトをfutures辞書に格納
                futures[executor.submit(encode_image, image)] = idx
            
            # 各Futureオブジェクトの結果を取得し、一時的なリストに格納
            for future in futures:
                idx = futures[future]
                img_base64, image_file_size = future.result()
                tmp_base64_image_list[idx] = img_base64
                tmp_image_file_size_list[idx] = f'{image_file_size}byte'
        
        # 一時的なリストの内容を元のリストに追加
        base64_image_list.extend(tmp_base64_image_list)
        image_file_size_list.extend(tmp_image_file_size_list)
        return base64_image_list, image_file_size_list
    except Exception as e:
        raise

def convert_pdf_to_image(doc, base64_image_list, image_file_size_list, ext):
    """
    PDFを画像に変換し、base64エンコードする関数
    """
    images = []  # 各ページの画像を格納するリスト
    exts = []  # 各画像の拡張子を格納するリスト
    
    # PDFの各ページを処理
    for page_number in range(len(doc)):
        page = doc.load_page(page_number)  # ページを読み込む
        pix = page.get_pixmap(dpi=IMAGE_DPI)  # ページを画像に変換
        images.append(pix)  # 画像をリストに追加
        exts.append(ext)  # 拡張子をリストに追加
    
    # 画像をbase64にエンコード
    base64_image_list, image_file_size_list = convert_image_to_base64(base64_image_list, image_file_size_list, images, exts)
    
    return base64_image_list, image_file_size_list  # エンコードされた画像とファイルサイズのリストを返す