import os
import time
import timeout_decorator
import datetime
import re
import json
from flask import jsonify
from config import config_list
from approaches.approach import Approach
from util.createchatmessages import create_chat_messages
from util.logger import create_debug_querylog_error, create_debug_querylog_info, get_chat_messages_as_text
from openai import AzureOpenAI


FIRST_MODEL_ALLOW_CHUNK_MAX_LENGTH = int(os.environ.get("FIRST_MODEL_ALLOW_CHUNK_MAX_LENGTH") or "10000")
FIRST_MODEL_ALLOW_CHUNK_HEAD_LENGTH = int(os.environ.get("FIRST_MODEL_ALLOW_CHUNK_HEAD_LENGTH") or "200")
ALLOW_CHUNK_MAX_LENGTH = int(os.environ.get("ALLOW_CHUNK_MAX_LENGTH") or "80000")
ALLOW_CHUNK_HEAD_LENGTH = int(os.environ.get("ALLOW_CHUNK_HEAD_LENGTH") or "200")
AZURE_OPENAI_FIRST_DEPLOYMENT = os.environ.get("AZURE_OPENAI_FIRST_DEPLOYMENT") or "GPT16K"
AZURE_OPENAI_SECOND_DEPLOYMENT = os.environ.get("AZURE_OPENAI_SECOND_DEPLOYMENT") or "GPT-4o"

# ***加藤追記 
class ReadPrepRetrieveLLM(Approach):

    def __init__(self, model_name, config_list, api_config_list, endpoint, approach):
 
        self.preprocess_instance = api_config_list[endpoint]["preprocess_instance"]

        self.search_instance = api_config_list[endpoint]["search_instance"]
        self.search_client = config_list[approach]["search_client"]
        self.search_index = config_list[approach]["search_index"]
        self.sourcepage_field = config_list[approach]["sourcepage_field"]
        self.content_field = config_list[approach]["content_field"]
        self.blob_url = config_list[approach]["blob_url"]
        self.further_question_score = config_list[approach]["further_question_score"]
        self.search_engine = config_list[approach]["search_engine"]

        self.create_llm_answer_instance = api_config_list[endpoint]["create_llm_answer_instance"]
        self.embedding_deployment = config_list[approach]["embedding_deployment"]
        self.retry_count = config_list[approach]["retry_count"]
        self.retry_interval = config_list[approach]["retry_interval"]
        self.chat_temperature = config_list[approach]["chat_temperature"]
        self.output_max_token = config_list[approach]["output_max_token"]

        if model_name == AZURE_OPENAI_FIRST_DEPLOYMENT:
            self.chatgpt_deployment = config_list[approach]["first_deployment"]
            self.approx_max_tokens = config_list[approach]["first_model_approx_max_tokens"]
            self.allow_chunk_max_length = FIRST_MODEL_ALLOW_CHUNK_MAX_LENGTH
            self.allow_chunk_head_length = FIRST_MODEL_ALLOW_CHUNK_HEAD_LENGTH
        elif model_name == AZURE_OPENAI_SECOND_DEPLOYMENT:
            self.chatgpt_deployment = config_list[approach]["second_deployment"]
            self.approx_max_tokens = config_list[approach]["second_model_approx_max_tokens"]
            self.allow_chunk_max_length = ALLOW_CHUNK_MAX_LENGTH
            self.allow_chunk_head_length = ALLOW_CHUNK_HEAD_LENGTH
        else:
            # TODO:エラーログ記述
            pass


    # @timeout_decorator.timeout(180, use_signals=False)
    def run(self, history: list[dict], relevant_documents:list | bool, filters:dict, aggs:dict, overrides: dict, tenant: str, approach: str, env: str, openai_client:AzureOpenAI) -> any:
        dt = datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S")
        latestQuery = history[-1]['user']
        filters = filters
        aggs = aggs
        top = overrides.get("top") or 10
        #STEP2,3をやらないとanswer_textがなく出力を作る際にエラーになるので最初に定義
        answertext = ""
        #STEP2をやらないとscoreが存在せず、ログの出力でエラー出るので最初に定義
        score = None
        try:
            # STEP 1: Generate an optimized keyword search query based on the chat history and the last question 
            startTime1 = time.time()
            if self.preprocess_instance:
                q = self.preprocess_instance.create_search_keyword(instance = self, history=history, overrides = overrides, tenant = tenant, approach=approach, env=env, dt=dt, startTime=startTime1, openai_client=openai_client)
            else: 
                q = history[-1]['user']
            step1elapsedTime = time.time() - startTime1

            # STEP 2: Retrieve relevant documents from the search index 
            startTime2 = time.time()
            if self.search_instance:

                fulltext_search_query_body = self.get_fulltext_search_query_body(q,approach,filters,aggs)
                relevant_documents, score = self.search_instance.get_relevant_documents(instance = self, top = top, overrides=overrides, q = q, filters = filters, aggs=aggs,  fulltext_search_query_body=fulltext_search_query_body, get_vector_squery_body = self.get_vector_squery_body, tenant = tenant, approach = approach, env = env, latestQuery = latestQuery, dt = dt, startTime = startTime2, step1elapsedTime  = step1elapsedTime, openai_client=openai_client)

                if not relevant_documents:
                    answertext= config_list[approach]["search_failed_template"]
                    # 関連文書がないならLLMに回答作らせない
                    self.create_llm_answer_instance = False
                else:
                    answertext= config_list[approach]["search_success_template"]

                # Retrieve relevant classifications from the search index with the GPT optimized query when the score is less than further_question_score
                if score < self.further_question_score:
                    try:
                        query_body={
                            "query": {
                                "multi_match": {
                                    "query":  q,
                                    "fields": [ "content^10", "mykeyword^5","filetype","gyoumu_lv1^1","gyoumu_lv2^1","gyoumu_lv3^1","yakkan","finacial_year","GeneratedSummary^10","relatedQuestions^10" ] 
                                }
                            },
                            "size":0, # ファセット情報のみ取得
                            "aggs":{
                                "yakkan": { 
                                    "terms": {
                                        "field":"yakkan.keyword",
                                        "size": 6
                                    },
                                },
                                "gyoumu_lv2": { 
                                    "terms": {
                                        "field":"gyoumu_lv2.keyword",
                                        "size": 6
                                    },
                                }
                            } 
                        }  
                        faset_result_lv2_yakkan = self.search_client.search(index=self.search_index, body=query_body, ignore=400)
                        # 業務Lv2なし&業務Lv1あり の業務Lv1 を取得
                        query_body={ 
                            "query": { 
                                "bool": {
                                    "must": [
                                        {
                                            "multi_match": {
                                                "query":  q,
                                                "fields":  [ "content^10", "mykeyword^5","filetype","gyoumu_lv1^1","gyoumu_lv2^1","gyoumu_lv3^1","yakkan","finacial_year","GeneratedSummary^10","relatedQuestions^10" ],
                                            }
                                        },
                                        { "term": {"gyoumu_lv2.keyword": ""} },
                                        {
                                            "bool":{
                                                "must_not": [{ "term": {"gyoumu_lv1.keyword": ""}}]
                                            }
                                        }
                                        
                                    ]
                                }
                            },
                            "size":0, # ファセット情報のみ取得
                            "aggs":{
                                "gyoumu_lv1": { 
                                    "terms": {
                                        "field":"gyoumu_lv1.keyword",
                                        "size": 5
                                    },
                                }
                            } 
                        }  
                        faset_result_lv1 = self.search_client.search(index=self.search_index, body=query_body, ignore=400)

                    except Exception as e:
                        step2elapsedTime=time.time() - startTime2
                        params = {
                            "answer": "step2 cognitive search apiで例外発生",
                            "search":q.replace('\n', '<br>'),
                            "prompt":prompt.replace('\n', '<br>'),
                            "step1elapsedTime":step1elapsedTime,
                            "step2elapsedTime":step2elapsedTime,
                            "3rd_score": score,
                            "search_engine": self.search_engine,
                        }
                        create_debug_querylog_error(dt, env, latestQuery, overrides, approach, tenant, **params)
                        raise Exception("step2 Cognitive Search APIでエラーが発生しました")
                    
                    step2elapsedTime=time.time() - startTime2

                    facets = {**faset_result_lv2_yakkan["aggregations"], **faset_result_lv1["aggregations"]}
                    gyoumu_lv1_list = ""
                    gyoumu_lv2_list=""
                    yakkan_list = ""

                    for index, item in enumerate(facets["gyoumu_lv2"]["buckets"]):
                        if item["key"] == "":
                            continue
                        record = "・" + re.sub(r"^\d+\.", "", str(item["key"]))
                        gyoumu_lv2_list += record + "\n"

                    for index, item in enumerate(facets["yakkan"]["buckets"]):
                        if item["key"] =="":
                            continue
                        remove_index = re.sub(r"^\d+-\d+-\d+\s+|^\d+-\d+\s+|^\d+-\d+-別表+\s+", "", str(item["key"]))
                        record = "・" + re.sub(r"\[.*?\]$", "", remove_index)
                        yakkan_list += record + "\n"

                    for index, item in enumerate(facets["gyoumu_lv1"]["buckets"]):
                        if item["key"] =="":
                            continue
                        record = "・" + re.sub(r"^\d+\.|^[①②③④⑤⑥⑦⑧⑨][－-]?", "", str(item["key"]))
                        gyoumu_lv1_list += record + "\n"   
                
                    facets_list = gyoumu_lv2_list + yakkan_list + gyoumu_lv1_list

                    if facets != "":
                        further_questions_message = """

                        例えば以下の観点を参考に、知りたい内容をもう少し詳しく教えていただけますか？
                        """
                        answertext += further_questions_message + facets_list
                else:
                    step2elapsedTime=time.time() - startTime2
            else:
                step2elapsedTime=time.time() - startTime2
            
            # STEP 3: Generate a contextual and content specific answer using the search results and chat history
            startTime3 = time.time()
            log_params = {
                    "search":q.replace('\n', '<br>'), 
                    "search_engine":self.search_engine,
                    "3rd_score": score,
                    "step1elapsedTime":step1elapsedTime,
                    "step2elapsedTime":step2elapsedTime,
            }

            # 回答生成を行う場合、検索結果を入力可能な文字数へ圧縮する文字数制限
            if self.create_llm_answer_instance and relevant_documents:
                relevant_documents = self.trimchunklength(relevant_documents)

            #関連文書あるなら文字列連結、ないなら空文字
            content = "\n".join(relevant_documents) if relevant_documents else ""
            prompt_template = overrides.get("prompt_template") or ""
            auto_prompt = overrides.get("autoPromptMode")
            messages = create_chat_messages(history, tenant, approach, prompt_template, content, auto_prompt, self.chatgpt_deployment, self.approx_max_tokens)

            #ログ出力用に文字列に変換する
            prompt = get_chat_messages_as_text(messages,self.approx_max_tokens)
        
            if self.create_llm_answer_instance:
                marge_answertext = ""
                error_json_data = {}
                # 関連文書をつかってLLMが回答作成する
                # 例えばrrrmixc,rrrlwff_a
                if relevant_documents:
                    try:
                        # ストリーミング出力では長文を送れないためdata_pointsを小出しで送る
                        # 小出しに送るため2000文字ごとに分割する
                        relevant_documents_string = json.dumps(relevant_documents)
                        relevant_documents_string_split = [relevant_documents_string[i:i+2000] for i in range(0, len(relevant_documents_string), 2000)]
                        relevant_documents_index = 0

                        answertext = self.create_llm_answer_instance.get_answer(instance=self, overrides=overrides, messages=messages, tenant=tenant, approach=approach, env=env, latestQuery=q, temperature=self.chat_temperature, max_tokens=self.output_max_token,approx_max_tokens = self.approx_max_tokens, dt=dt, startTime=startTime3, openai_client=openai_client,**log_params) #+ answertext                
                        for event in answertext:
                            if not len(event.choices):
                                continue
                            else:
                                for choice in event.choices:
                                    if choice.delta and choice.finish_reason is None:
                                        # data_pointsを分割して送る。
                                        data_points = {}
                                        if len(relevant_documents_string_split) > relevant_documents_index:
                                            data_points = {"data_points": relevant_documents_string_split[relevant_documents_index]}  
                                            relevant_documents_index = relevant_documents_index+1

                                        # 回答をcontentに入れる
                                        content = choice.delta.content
                                        json_data = json.dumps({"content": content, **data_points})
                                        marge_answertext += content
                                        yield f"{json_data}\n"
                        
                        # data_pointsがまだ送り切れてなければ追加でフロントに送る
                        if len(relevant_documents_string_split)> relevant_documents_index:
                            for t in relevant_documents_string_split[relevant_documents_index:]:
                                json_data = json.dumps({"content": "", "data_points":t})
                                yield f"{json_data}\n"
                        
                        step3elapsedTime=time.time() - startTime3
                        self.handle_success_log(dt, env, latestQuery, overrides, q, prompt, marge_answertext, score, approach, tenant, step1elapsedTime, step2elapsedTime, step3elapsedTime)

                    except Exception as e:
                        error_json_data = {"error": str(e)}

                    final_result = {"content":"", "thoughts": "", **error_json_data}
                    yield json.dumps(final_result)
                
                # 関連文書ではなくクエリで回答生成
                # 例えばcrrr, crrr_as
                else:
                    try:
                        answertext = self.create_llm_answer_instance.get_answer(instance=self, overrides=overrides, messages=messages, tenant=tenant, approach=approach, env=env, latestQuery=q, temperature=self.chat_temperature, max_tokens=self.output_max_token, approx_max_tokens = self.approx_max_tokens, dt=dt, startTime=startTime3, openai_client=openai_client,**log_params) #+ answertext
                        for event in answertext:
                            if not len(event.choices):
                                continue
                            else:
                                for choice in event.choices:
                                    if choice.delta and choice.finish_reason is None:
                                        content = choice.delta.content
                                        json_data = json.dumps({"content": content})
                                        marge_answertext += content
                                        yield f"{json_data}\n"

                        step3elapsedTime=time.time() - startTime3
                        self.handle_success_log(dt, env, latestQuery, overrides, q, prompt, marge_answertext, score, approach, tenant, step1elapsedTime, step2elapsedTime, step3elapsedTime)

                    except Exception as e:
                        error_json_data = {"error": str(e)}
                    
                    final_result = {"content":"", "thoughts" : "" , **error_json_data}
                    yield json.dumps(final_result)

            # 例えばrrrlwf,rrrf
            else:
                step3elapsedTime=time.time() - startTime3
                self.handle_success_log(dt, env, latestQuery, overrides, q, prompt, answertext, score, approach, tenant, step1elapsedTime, step2elapsedTime, step3elapsedTime)
                final_result = {"data_points": relevant_documents,"answer": answertext,"thoughts": f"Engine:{self.chatgpt_deployment}<BR><BR>Step1 elapsedtime:<br>{step1elapsedTime}<br>Step2 elapsedtime:<br>{step2elapsedTime}<br>Step3 elapsedtime:<br>{step3elapsedTime}<br><br>Searched for:<br>{q}<br><br>Prompt:<br>" + prompt.replace('\n', '<br>'),}
                yield json.dumps(final_result)
        except Exception as e:
            error_json_data = {"error": str(e)}
            yield json.dumps(error_json_data)

    def get_fulltext_search_query_body(self, q:str, approach:str, filters:dict, aggs:dict):
        query_body = { 
            "query": {
                "bool" : {
                    "must" : {
                        "multi_match": {
                            "query":  q,
                            "fields": config_list[approach]["fields"] 
                        }
                    },
                    "filter": []
                }
            },
            "size":20,
            "_source": {
                "excludes": ["content_vector","relatedQuestions_vector"]  # 取得しないフィールド
            },
        }
        #フロントで選択したフィルタ条件を設定
        for key in filters:
            if key in aggs:
                terms = {
                    "terms":{
                        aggs[key]["terms"]["field"] :filters[key] 
                    }                           
                }
                query_body["query"]["bool"]["filter"].append(terms)

        return query_body

    def get_vector_squery_body(self, vector, filters:dict , aggs:dict ):
        query_body = { 
            "knn": [
                {
                    "field": "relatedQuestions_vector",
                    "query_vector": vector,
                    "k": 20,
                    "filter": [],
                    "num_candidates": 200,
                }
            ],
            "size":20,
            "_source": {
                "excludes": ["content_vector","relatedQuestions_vector"]  # 取得しないフィールド
            }
        }
        #フロントで選択したフィルタ条件を設定
        for key in filters:
            if key in aggs:
                terms = {
                    "terms":{
                        aggs[key]["terms"]["field"] :filters[key] 
                    }                           
                }
                query_body["knn"][0]["filter"].append(terms)

        return query_body

    def handle_success_log(self, dt:str, env:str, latestQuery:str, overrides:dict, q:str, prompt:str, marge_answertext:str, score:int, approach:str, tenant:str, step1elapsedTime:float, step2elapsedTime:float, step3elapsedTime:float, **kwargs):
        """
        infoログを出力します。
        """
        params = {
            "search":q.replace('\n', '<br>'),
            "prompt":prompt.replace('\n', '<br>'),
            "answer":marge_answertext.replace('\n', '<br>'),
            "engine":self.chatgpt_deployment,
            "temparature":self.chat_temperature,
            "3rd_score": score,
            "search_engine": self.search_engine,
            "step1elapsedTime":step1elapsedTime,
            "step2elapsedTime":step2elapsedTime,
            "step3elapsedTime":step3elapsedTime,
            **kwargs
        }
        create_debug_querylog_info(dt, env, latestQuery, overrides, approach, tenant, **params)

    def trimchunklength(self, relevant_documents):
        sentence_length= 0
        for i, sentence in enumerate(relevant_documents):
            sentence_length +=len(sentence)
            if(sentence_length>self.allow_chunk_max_length ):
                back_sentence_length =sentence_length-self.allow_chunk_max_length
                if(len(sentence[:-back_sentence_length])>self.allow_chunk_head_length ):
                    relevant_documents[i]=sentence[:-back_sentence_length]
                    relevant_documents = relevant_documents[:i+1]
                    break
                else:
                    relevant_documents = relevant_documents[:i]
                    break
        return relevant_documents       