import json
from esg_src.esg_config import esg_config_list
from util.getencodingmodel import get_encoding_model

def create_chat_messages(history: list[dict], tenant:str, approach:str, chatgpt_deployment:str, template:str, sources:str, approx_max_tokens) -> list[dict[str, str]]:
    """

    ソースファイルの文字列を、ChatCompletionの引数の形式に変換する
    例
    history = [{ user:"トピック:CO2削減 評価項目：2023年目標(政府目標との整合性)" 評価基準:温室効果ガス(二酸化炭素のみも可)の排出量(2013年度比)が2021年度策定の政府目標(46%)と同等以上 } ] 
    sources = "0.@@@文書名:xxx @@@参考リンク:xxx @@@本文:xxx 1.@@@文書名:xxx"
    ↓
    messages = [
        { "role" : "system" , "content" : self.system_prompt} ,
        { "role" : "user" , "content" : "user:"トピック:CO2削減 評価項目：2023年目標(政府目標との整合性)" 評価基準:温室効果ガス(二酸化炭素のみも可)の排出量(2013年度比)が2021年度策定の政府目標(46%)と同等以上 "
          + "###引用情報###" + "0.@@@文書名:xxx @@@参考リンク:xxx @@@本文:xxx 1.@@@文書名:xxx" } 
    ]
    """
    system_prompt = esg_config_list[approach]["system_prompt"]

    messages = [
        { 
            "role":"system",
            "content":system_prompt
        }
    ]
    
    user_message = history[-1]['user']
    len_flag = 0
    if len( get_encoding_model(chatgpt_deployment).encode(user_message) ) > approx_max_tokens*4:
        len_flag = 1
    # テンプレート文を追加
    if template and approach in esg_config_list and len(esg_config_list[approach]["prompt_template"]) > int(template):
        select_template = esg_config_list[approach]["prompt_template"][int(template)]
        user_message = select_template.replace("$1", user_message)

    if sources :
        user_message += f"\n###引用情報###\n{sources}"

    messages.append(
        {
            "role":"user",
            "content":user_message,
        }
    )

    used_chars = system_prompt
    used_chars += user_message
    if len( get_encoding_model(chatgpt_deployment).encode(used_chars) ) > approx_max_tokens*4:
        return messages, len_flag

    history = history[:len(history)-1]
    for chat in reversed(history):
        used_chars += chat['user'] + chat['bot']
        if len( get_encoding_model(chatgpt_deployment).encode(used_chars) ) > approx_max_tokens*4:
            break

        user_chat = {
            "role":"user",
            "content":chat['user']
        }
        messages.insert(1, user_chat)
        assistant_chat = {
            "role":"assistant",
            "content":chat['bot']
        }
        messages.insert(2, assistant_chat)
    
    return messages,len_flag