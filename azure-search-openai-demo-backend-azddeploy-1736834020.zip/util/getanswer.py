import openai
import time
import json
from util.logger import create_debug_querylog_error, get_chat_messages_as_text
from openai import AzureOpenAI

# ***加藤追記 定義ファイルでインスタンス化して渡したいのでクラス化
class GetGptAnswer():   

    def handle_openai_error(self,instance, startTime:str, dt:str, tenant:str, approach:str, env:str, latestQuery:str, prompt:str, overrides:dict, answer:str, count, **kwargs):
        """
        エラーログを出力します。
        """
        elapsedTime=time.time() - startTime
        params = {
            "answer": answer,
            "prompt": prompt.replace('\n', '<br>'),
            "engine": instance.chatgpt_deployment,
            **kwargs
        }
        if kwargs:
            params["step3elapsedTime"] = elapsedTime
        else:
            params["openAIelapsedtime"] = elapsedTime

        if count:
            params["retry"] = f"{count + 1}/{instance.retry_count} (Interval:{instance.retry_interval}sec)"

        create_debug_querylog_error(dt, env, latestQuery, overrides, approach, tenant, **params)

    def get_answer(self,instance, overrides: dict, messages:list[dict[str, str]], tenant:str, approach: str, env: str, latestQuery:str, temperature:int, max_tokens:int,approx_max_tokens:int, dt, startTime,openai_client:AzureOpenAI, **kwargs) -> str: 
        """
        openAIからの回答を取得します
        """

        # ログ出力用に文字列に変換する
        prompt = get_chat_messages_as_text(messages,approx_max_tokens)
        
        for count in range( instance.retry_count ):

            try:
                chatCompletion = openai_client.chat.completions.create(
                    model=instance.chatgpt_deployment,
                    messages = messages,
                    temperature=temperature, 
                    max_tokens=max_tokens, 
                    n=1, 
                    stop=None,
                    stream=True,
                    timeout=100)
                
            except openai.BadRequestError as e:
                answer = f"Step3 OpenAI api で {e.code} Error発生"
                self.handle_openai_error(instance, startTime, dt, tenant, approach, env, latestQuery, prompt, overrides, answer, False, **kwargs)
                if e.code == "context_length_exceeded":
                    raise Exception("プロンプトの文字数を減らしてください")
                else:
                    raise Exception("プロンプトを修正してください") # invalid_prompt
            except openai.APITimeoutError as e:
                answer = f"Step3 OpenAI api でTimeOut発生"
                self.handle_openai_error(instance, startTime, dt, tenant, approach, env, latestQuery, prompt, overrides, answer, False, **kwargs)
                raise Exception("タイムアウトが発生しました")

            except Exception as e:
                answer = f"Step3 openAI apiで例外発生"
                self.handle_openai_error(instance, startTime, dt, tenant, approach, env, latestQuery, prompt, overrides, answer, count, **kwargs)

                if count + 1 >=instance.retry_count :
                    raise Exception(f"Step3 OpenAI APIでエラーが発生しました")
                else:
                    time.sleep( instance.retry_interval )
            else:
                break
        else:
            raise Exception(f"Step3 OpenAI APIでエラーが発生しました")

        return chatCompletion
