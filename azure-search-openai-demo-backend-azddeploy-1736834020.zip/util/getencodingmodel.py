import os
import tiktoken

AZURE_OPENAI_FIRST_DEPLOYMENT = os.environ.get("AZURE_OPENAI_FIRST_DEPLOYMENT") or "GPT16K"
AZURE_OPENAI_SECOND_DEPLOYMENT = os.environ.get("AZURE_OPENAI_SECOND_DEPLOYMENT") or "GPT-4o"
AZURE_OPENAI_FIRST_DEPLOYMENT_ENCODING_NAME = os.environ.get("AZURE_OPENAI_FIRST_DEPLOYMENT_ENCODING_NAME") or "cl100k_base"
AZURE_OPENAI_SECOND_DEPLOYMENT_ENCODING_NAME = os.environ.get("AZURE_OPENAI_SECOND_DEPLOYMENT_ENCODING_NAME") or "o200k_base"

def get_encoding_model(deployment_name):
    # モデル名とtiktokenのエンコーディング名をマッピングする辞書
    _model_to_encoding = {
        AZURE_OPENAI_FIRST_DEPLOYMENT: AZURE_OPENAI_FIRST_DEPLOYMENT_ENCODING_NAME,
        AZURE_OPENAI_SECOND_DEPLOYMENT: AZURE_OPENAI_SECOND_DEPLOYMENT_ENCODING_NAME 
    }

    encoding_name = _model_to_encoding.get(deployment_name)

    if not encoding_name:
        raise ValueError(f"Unsupported model name: {deployment_name}")

    return tiktoken.get_encoding(encoding_name)