def nonewlines(s: str) -> str:
    return s.replace('\r\n', ' ').replace('\n', ' ').replace('\r', ' ')

def stringnewlines(s: str) -> str:
    return s.replace('\r\n', '\\n').replace('\n', '\\n').replace('\r', '\\n')
