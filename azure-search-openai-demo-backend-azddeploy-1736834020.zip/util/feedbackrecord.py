from elasticsearch import Elasticsearch
import logging

#書状WF
#like/dislikeのカウント数を取得
def searchForUpdateDoc(client, citationParts, search_index):
    #elasticsearchに投げる内容
    query_body={ 
        "_source": {
            "excludes": [ "content_vector","relatedQuestions_vector" ] #取得しないフィールド
        },
        "query": { 
          "bool" : {
            "must" : {
              "match_all": {}
            },
            "filter": {
              "term" : {
                "sourcepage.keyword" : citationParts
              }
            }
          }
        },
        "size":10000
    }

    #elasticsearchで検索
    result = client.search(index = search_index , body=query_body, ignore=400)

    if len(result["hits"]["hits"])==0:
        return("error")

    like_count = result["hits"]["hits"][0]["_source"].get('like_count', 0 )
    dislike_count = result["hits"]["hits"][0]["_source"].get('dislike_count',0)

    return result["hits"]["hits"][0]["_id"], like_count , dislike_count

#/askdata時    
#likeのカウント情報を更新    
def likeFeedbackUpdate(client, citationList,search_index):
    #リストに対し以下の処理を行う
    for i in range(len(citationList)):
        try:
          citationParts = citationList[i]

          #検索しlike_countを呼び出す
          doc_id , like_count , dislike_count = searchForUpdateDoc(client,citationParts,search_index)  

          #選択されたcitationに対しLike+1する
          like_count = like_count + 1 
          
          #like_countを格納する
          counter = {
              "doc": {
                  "like_count" : like_count,
                  "dislike_count" : dislike_count,
              }           
          }     
          
          #更新
          client.update(index=search_index, id=doc_id, body=counter)

        except Exception as e:
            logging.exception("Exception in /answer")
            continue

    return like_count , dislike_count

##「ほしい回答がみつからなかった」時    
#dislikeのカウント情報を更新    
def dislikeFeedbackUpdate(client, citationList,search_index):
    #リストに対し以下の処理を行う
    for i in range(len(citationList)):
        try:
          citationParts = citationList[i]

          #検索しlike_countを呼び出す
          doc_id , like_count , dislike_count = searchForUpdateDoc(client,citationParts,search_index)  

          #選択されたcitationに対しLike+1する
          dislike_count = dislike_count + 1 
          
          #dislike_countを格納する
          counter = {
              "doc": {
                  "like_count" : like_count,
                  "dislike_count" : dislike_count,
              }           
          }     
          
          #更新
          client.update(index=search_index, id=doc_id, body=counter)

        except Exception as e:
          logging.exception("Exception in /feedback")
          continue

    return like_count , dislike_count

#クリック回数を取得
def clickedCitationCount(client, clickedCitation,search_index):
    #elasticsearchに投げる内容
    query_body={ 
        "_source": {
            "excludes": [ "content_vector","relatedQuestions_vector" ] #取得しないフィールド
       },
        "query": { 
          "bool" : {
            "must" : {
              "match_all": {}
            },
            "filter": {
              "term" : {
                "sourcepage.keyword" : clickedCitation
              }
            }
          }
        },
        "size":10000 
    }
    #elasticsearchで検索
    result = client.search(index=search_index, body=query_body, ignore=400)

    if len(result["hits"]["hits"])==0:
        return("error")

    click_count = result["hits"]["hits"][0]["_source"].get('click_count', 0 )

    return result["hits"]["hits"][0]["_id"], click_count

#クリック回数を更新
def clickCountUpdate(client, clickedCitation,search_index):
    try:
      #検索しclick_countを呼び出す
      doc_id , click_count = clickedCitationCount(client,clickedCitation,search_index)  

      #選択されたcitationに対しLike+1する
      click_count = click_count + 1 
      
      #click_countを格納
      counter = {
          "doc": {
              "click_count" : click_count,
          }           
      }      
      
      #更新
      client.update(index=search_index, id=doc_id, body=counter)

    except Exception as e:
      logging.exception("Exception in /citationClick")

    return click_count